import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const city = searchParams.get("city") || "Moscow"

    // Step 1: Get coordinates for the city using Open-Meteo Geocoding API (free, no key needed)
    const geocodingUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(
      city,
    )}&count=1&language=en&format=json`

    const geocodingResponse = await fetch(geocodingUrl)

    if (!geocodingResponse.ok) {
      return NextResponse.json({ error: "City not found" }, { status: 404 })
    }

    const geocodingData = await geocodingResponse.json()

    if (!geocodingData.results || geocodingData.results.length === 0) {
      return NextResponse.json({ error: "City not found" }, { status: 404 })
    }

    const location = geocodingData.results[0]
    const { latitude, longitude, name } = location

    // Step 2: Get weather data using coordinates (free, no key needed)
    const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m&timezone=auto`

    const weatherResponse = await fetch(weatherUrl)

    if (!weatherResponse.ok) {
      return NextResponse.json({ error: "Failed to fetch weather" }, { status: 500 })
    }

    const weatherData = await weatherResponse.json()
    const current = weatherData.current

    // Map weather codes to descriptions and icons
    const weatherCode = current.weather_code
    const { description, icon } = getWeatherInfo(weatherCode)

    // Transform the data to our format
    const result = {
      city: name,
      temperature: Math.round(current.temperature_2m),
      description: description,
      humidity: current.relative_humidity_2m,
      windSpeed: current.wind_speed_10m,
      icon: icon,
    }

    return NextResponse.json(result)
  } catch (error) {
    console.error("Weather API error:", error)
    return NextResponse.json({ error: "Failed to fetch weather data" }, { status: 500 })
  }
}

// Weather codes from Open-Meteo API documentation
function getWeatherInfo(code: number): { description: string; icon: string } {
  const weatherMap: Record<number, { description: string; icon: string }> = {
    0: { description: "Clear sky", icon: "01d" },
    1: { description: "Mainly clear", icon: "01d" },
    2: { description: "Partly cloudy", icon: "02d" },
    3: { description: "Overcast", icon: "03d" },
    45: { description: "Foggy", icon: "50d" },
    48: { description: "Depositing rime fog", icon: "50d" },
    51: { description: "Light drizzle", icon: "09d" },
    53: { description: "Moderate drizzle", icon: "09d" },
    55: { description: "Dense drizzle", icon: "09d" },
    61: { description: "Slight rain", icon: "10d" },
    63: { description: "Moderate rain", icon: "10d" },
    65: { description: "Heavy rain", icon: "10d" },
    71: { description: "Slight snow", icon: "13d" },
    73: { description: "Moderate snow", icon: "13d" },
    75: { description: "Heavy snow", icon: "13d" },
    77: { description: "Snow grains", icon: "13d" },
    80: { description: "Slight rain showers", icon: "09d" },
    81: { description: "Moderate rain showers", icon: "09d" },
    82: { description: "Violent rain showers", icon: "09d" },
    85: { description: "Slight snow showers", icon: "13d" },
    86: { description: "Heavy snow showers", icon: "13d" },
    95: { description: "Thunderstorm", icon: "11d" },
    96: { description: "Thunderstorm with slight hail", icon: "11d" },
    99: { description: "Thunderstorm with heavy hail", icon: "11d" },
  }

  return weatherMap[code] || { description: "Unknown", icon: "01d" }
}
