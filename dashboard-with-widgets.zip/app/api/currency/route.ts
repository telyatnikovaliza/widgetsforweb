import { NextResponse } from "next/server"

// Using exchangerate-api.com free API (no key required for basic usage)
const CURRENCY_API_URL = "https://api.exchangerate-api.com/v4/latest/USD"

export async function GET() {
  try {
    const response = await fetch(CURRENCY_API_URL)

    if (!response.ok) {
      throw new Error("Failed to fetch currency rates")
    }

    const data = await response.json()

    return NextResponse.json({
      rates: data.rates,
      base: "USD",
      date: data.date,
    })
  } catch (error) {
    console.error("Currency API error:", error)

    // Fallback rates if API fails
    return NextResponse.json({
      rates: {
        USD: 1,
        EUR: 0.92,
        GBP: 0.79,
        RUB: 92.5,
        JPY: 149.5,
        CNY: 7.24,
      },
      base: "USD",
      date: new Date().toISOString(),
    })
  }
}
