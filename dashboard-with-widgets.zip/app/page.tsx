"use client"

import { WeatherWidget } from "@/components/widgets/weather-widget"
import { ClockWidget } from "@/components/widgets/clock-widget"
import { TodoWidget } from "@/components/widgets/todo-widget"
import { QuoteWidget } from "@/components/widgets/quote-widget"
import { ProductivityWidget } from "@/components/widgets/productivity-widget"
import { CalendarWidget } from "@/components/widgets/calendar-widget"

export default function DashboardPage() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 dark:from-gray-900 dark:via-purple-900 dark:to-blue-900 p-8">
      <div className="max-w-7xl mx-auto">
        <header className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-2">Dashboard with Widgets</h1>
          <p className="text-gray-600 dark:text-gray-300">Your personalized productivity dashboard</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <WeatherWidget />
          <ClockWidget />
          <ProductivityWidget />
          <CalendarWidget />
          <TodoWidget />
          <QuoteWidget />
        </div>
      </div>
    </main>
  )
}
