export interface WidgetConfig {
  id: string
  type: "weather" | "clock" | "productivity" | "calendar" | "todo" | "quote"
}
