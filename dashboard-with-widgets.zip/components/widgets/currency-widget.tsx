"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { WidgetWrapper } from "./widget-wrapper"
import { ArrowDownUp } from "lucide-react"

interface CurrencyWidgetProps {
  id: string
  position: { x: number; y: number }
  onPositionChange: (id: string, position: { x: number; y: number }) => void
  onRemove: (id: string) => void
}

const currencies = ["USD", "EUR", "GBP", "RUB", "JPY", "CNY"]

export function CurrencyWidget({ id, position, onPositionChange, onRemove }: CurrencyWidgetProps) {
  const [amount, setAmount] = useState("100")
  const [fromCurrency, setFromCurrency] = useState("USD")
  const [toCurrency, setToCurrency] = useState("EUR")
  const [result, setResult] = useState<number | null>(null)
  const [loading, setLoading] = useState(false)
  const [rates, setRates] = useState<Record<string, number>>({})

  useEffect(() => {
    fetchRates()
  }, [])

  useEffect(() => {
    if (rates && Object.keys(rates).length > 0) {
      convert()
    }
  }, [amount, fromCurrency, toCurrency, rates])

  const fetchRates = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/currency")
      const data = await response.json()
      setRates(data.rates)
    } catch (error) {
      console.error("Failed to fetch rates:", error)
    } finally {
      setLoading(false)
    }
  }

  const convert = () => {
    const value = Number.parseFloat(amount)
    if (isNaN(value) || !rates[fromCurrency] || !rates[toCurrency]) {
      setResult(null)
      return
    }

    // Convert to USD first, then to target currency
    const inUSD = value / rates[fromCurrency]
    const converted = inUSD * rates[toCurrency]
    setResult(converted)
  }

  const swapCurrencies = () => {
    setFromCurrency(toCurrency)
    setToCurrency(fromCurrency)
  }

  return (
    <WidgetWrapper id={id} position={position} onPositionChange={onPositionChange} onRemove={onRemove}>
      <Card className="p-6 w-80 bg-white/90 dark:bg-gray-800/90 backdrop-blur">
        <h3 className="text-xl font-bold mb-4">Currency Converter</h3>

        <div className="space-y-4">
          <div>
            <label className="text-sm text-gray-600 dark:text-gray-400 mb-1 block">Amount</label>
            <Input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Enter amount"
            />
          </div>

          <div>
            <label className="text-sm text-gray-600 dark:text-gray-400 mb-1 block">From</label>
            <select
              value={fromCurrency}
              onChange={(e) => setFromCurrency(e.target.value)}
              className="w-full p-2 border rounded-md bg-background"
            >
              {currencies.map((curr) => (
                <option key={curr} value={curr}>
                  {curr}
                </option>
              ))}
            </select>
          </div>

          <div className="flex justify-center">
            <Button onClick={swapCurrencies} variant="ghost" size="sm">
              <ArrowDownUp className="h-4 w-4" />
            </Button>
          </div>

          <div>
            <label className="text-sm text-gray-600 dark:text-gray-400 mb-1 block">To</label>
            <select
              value={toCurrency}
              onChange={(e) => setToCurrency(e.target.value)}
              className="w-full p-2 border rounded-md bg-background"
            >
              {currencies.map((curr) => (
                <option key={curr} value={curr}>
                  {curr}
                </option>
              ))}
            </select>
          </div>

          {loading ? (
            <div className="text-center py-4">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary mx-auto"></div>
            </div>
          ) : result !== null ? (
            <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg text-center">
              <p className="text-2xl font-bold">
                {result.toFixed(2)} {toCurrency}
              </p>
            </div>
          ) : null}
        </div>
      </Card>
    </WidgetWrapper>
  )
}
