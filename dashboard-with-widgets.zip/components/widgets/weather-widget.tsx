"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Cloud, CloudRain, Sun, Wind, Droplets } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

interface WeatherData {
  city: string
  temperature: number
  description: string
  humidity: number
  windSpeed: number
  icon: string
}

export function WeatherWidget() {
  const [weather, setWeather] = useState<WeatherData | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [city, setCity] = useState("Moscow")
  const [inputCity, setInputCity] = useState("Moscow")

  useEffect(() => {
    fetchWeather(city)
  }, [city])

  const fetchWeather = async (cityName: string) => {
    setLoading(true)
    setError(null)

    try {
      const response = await fetch(`/api/weather?city=${encodeURIComponent(cityName)}`)

      if (!response.ok) {
        throw new Error("City not found")
      }

      const data = await response.json()
      setWeather(data)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to fetch weather")
      setWeather(null)
    } finally {
      setLoading(false)
    }
  }

  const handleSearch = () => {
    if (inputCity.trim()) {
      setCity(inputCity.trim())
    }
  }

  const getWeatherIcon = (iconCode: string) => {
    if (iconCode.includes("01")) return <Sun className="h-12 w-12 text-yellow-500" />
    if (iconCode.includes("02") || iconCode.includes("03") || iconCode.includes("04"))
      return <Cloud className="h-12 w-12 text-gray-400" />
    if (iconCode.includes("09") || iconCode.includes("10")) return <CloudRain className="h-12 w-12 text-blue-500" />
    return <Cloud className="h-12 w-12 text-gray-400" />
  }

  return (
    <Card className="p-6 w-full shadow-lg">
      <h3 className="text-xl font-bold mb-4">Weather</h3>

      <div className="flex gap-2 mb-4">
        <Input
          placeholder="Enter city..."
          value={inputCity}
          onChange={(e) => setInputCity(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSearch()}
        />
        <Button onClick={handleSearch} size="sm">
          Search
        </Button>
      </div>

      {loading && (
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
        </div>
      )}

      {error && <div className="text-center py-8 text-red-500">{error}</div>}

      {weather && !loading && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-2xl font-bold">{weather.city}</h4>
              <p className="text-4xl font-bold mt-2">{Math.round(weather.temperature)}°C</p>
              <p className="text-gray-600 dark:text-gray-400 capitalize mt-1">{weather.description}</p>
            </div>
            <div>{getWeatherIcon(weather.icon)}</div>
          </div>

          <div className="grid grid-cols-2 gap-4 pt-4 border-t">
            <div className="flex items-center gap-2">
              <Droplets className="h-5 w-5 text-blue-500" />
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Humidity</p>
                <p className="font-semibold">{weather.humidity}%</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Wind className="h-5 w-5 text-gray-500" />
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Wind</p>
                <p className="font-semibold">{weather.windSpeed} m/s</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </Card>
  )
}
