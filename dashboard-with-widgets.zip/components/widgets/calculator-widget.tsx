"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { WidgetWrapper } from "./widget-wrapper"

interface CalculatorWidgetProps {
  id: string
  position: { x: number; y: number }
  onPositionChange: (id: string, position: { x: number; y: number }) => void
  onRemove: (id: string) => void
}

export function CalculatorWidget({ id, position, onPositionChange, onRemove }: CalculatorWidgetProps) {
  const [display, setDisplay] = useState("0")
  const [previousValue, setPreviousValue] = useState<number | null>(null)
  const [operation, setOperation] = useState<string | null>(null)
  const [newNumber, setNewNumber] = useState(true)

  const handleNumber = (num: string) => {
    if (newNumber) {
      setDisplay(num)
      setNewNumber(false)
    } else {
      setDisplay(display === "0" ? num : display + num)
    }
  }

  const handleOperation = (op: string) => {
    const current = Number.parseFloat(display)

    if (previousValue === null) {
      setPreviousValue(current)
    } else if (operation) {
      const result = calculate(previousValue, current, operation)
      setDisplay(String(result))
      setPreviousValue(result)
    }

    setOperation(op)
    setNewNumber(true)
  }

  const calculate = (a: number, b: number, op: string): number => {
    switch (op) {
      case "+":
        return a + b
      case "-":
        return a - b
      case "*":
        return a * b
      case "/":
        return a / b
      default:
        return b
    }
  }

  const handleEquals = () => {
    if (operation && previousValue !== null) {
      const current = Number.parseFloat(display)
      const result = calculate(previousValue, current, operation)
      setDisplay(String(result))
      setPreviousValue(null)
      setOperation(null)
      setNewNumber(true)
    }
  }

  const handleClear = () => {
    setDisplay("0")
    setPreviousValue(null)
    setOperation(null)
    setNewNumber(true)
  }

  const handleDecimal = () => {
    if (newNumber) {
      setDisplay("0.")
      setNewNumber(false)
    } else if (!display.includes(".")) {
      setDisplay(display + ".")
    }
  }

  const buttons = [
    ["7", "8", "9", "/"],
    ["4", "5", "6", "*"],
    ["1", "2", "3", "-"],
    ["0", ".", "=", "+"],
  ]

  return (
    <WidgetWrapper id={id} position={position} onPositionChange={onPositionChange} onRemove={onRemove}>
      <Card className="p-6 w-80 bg-white/90 dark:bg-gray-800/90 backdrop-blur">
        <h3 className="text-xl font-bold mb-4">Calculator</h3>

        <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg mb-4">
          <div className="text-3xl font-mono text-right overflow-hidden text-ellipsis">{display}</div>
        </div>

        <div className="space-y-2">
          {buttons.map((row, i) => (
            <div key={i} className="grid grid-cols-4 gap-2">
              {row.map((btn) => (
                <Button
                  key={btn}
                  onClick={() => {
                    if (btn === "=") handleEquals()
                    else if (["+", "-", "*", "/"].includes(btn)) handleOperation(btn)
                    else if (btn === ".") handleDecimal()
                    else handleNumber(btn)
                  }}
                  variant={["+", "-", "*", "/", "="].includes(btn) ? "default" : "secondary"}
                  className="h-12 text-lg font-semibold"
                >
                  {btn}
                </Button>
              ))}
            </div>
          ))}
          <Button onClick={handleClear} variant="destructive" className="w-full h-12">
            Clear
          </Button>
        </div>
      </Card>
    </WidgetWrapper>
  )
}
