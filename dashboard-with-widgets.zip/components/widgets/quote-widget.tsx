"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { RefreshCw, Quote } from "lucide-react"

interface QuoteData {
  text: string
  author: string
}

const QUOTES: QuoteData[] = [
  {
    text: "The only way to do great work is to love what you do.",
    author: "Steve Jobs",
  },
  {
    text: "Innovation distinguishes between a leader and a follower.",
    author: "Steve Jobs",
  },
  {
    text: "Life is what happens when you're busy making other plans.",
    author: "John Lennon",
  },
  {
    text: "The future belongs to those who believe in the beauty of their dreams.",
    author: "Eleanor Roosevelt",
  },
  {
    text: "It is during our darkest moments that we must focus to see the light.",
    author: "Aristotle",
  },
  {
    text: "Success is not final, failure is not fatal: it is the courage to continue that counts.",
    author: "Winston Churchill",
  },
  {
    text: "The way to get started is to quit talking and begin doing.",
    author: "Walt Disney",
  },
  {
    text: "Don't let yesterday take up too much of today.",
    author: "Will Rogers",
  },
  {
    text: "You learn more from failure than from success. Don't let it stop you. Failure builds character.",
    author: "Unknown",
  },
  {
    text: "It's not whether you get knocked down, it's whether you get up.",
    author: "Vince Lombardi",
  },
  {
    text: "If you are working on something that you really care about, you don't have to be pushed. The vision pulls you.",
    author: "Steve Jobs",
  },
  {
    text: "People who are crazy enough to think they can change the world, are the ones who do.",
    author: "Rob Siltanen",
  },
  {
    text: "Failure will never overtake me if my determination to succeed is strong enough.",
    author: "Og Mandino",
  },
  {
    text: "We may encounter many defeats but we must not be defeated.",
    author: "Maya Angelou",
  },
  {
    text: "Knowing is not enough; we must apply. Wishing is not enough; we must do.",
    author: "Johann Wolfgang Von Goethe",
  },
]

export function QuoteWidget() {
  const [quote, setQuote] = useState<QuoteData>(QUOTES[0])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    getRandomQuote()
  }, [])

  const getRandomQuote = () => {
    setLoading(true)
    setTimeout(() => {
      const randomIndex = Math.floor(Math.random() * QUOTES.length)
      setQuote(QUOTES[randomIndex])
      setLoading(false)
    }, 300)
  }

  return (
    <Card className="p-6 w-full shadow-lg">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-bold flex items-center gap-2">
          <Quote className="h-5 w-5" />
          Quote of the Day
        </h3>
        <Button onClick={getRandomQuote} size="icon" variant="ghost" disabled={loading}>
          <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
        </Button>
      </div>

      {loading ? (
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
        </div>
      ) : (
        <div className="space-y-4">
          <blockquote className="text-lg italic text-gray-700 dark:text-gray-300 border-l-4 border-primary pl-4">
            "{quote.text}"
          </blockquote>
          <p className="text-right text-gray-600 dark:text-gray-400 font-medium">— {quote.author}</p>
        </div>
      )}
    </Card>
  )
}
