"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"

export function ClockWidget() {
  const [time, setTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date())
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false,
    })
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  return (
    <Card className="p-6 w-full shadow-lg">
      <h3 className="text-xl font-bold mb-4">Clock</h3>
      <div className="text-center space-y-2">
        <div className="text-5xl font-bold font-mono tracking-wider">{formatTime(time)}</div>
        <div className="text-sm text-gray-600 dark:text-gray-400">{formatDate(time)}</div>
      </div>
    </Card>
  )
}
