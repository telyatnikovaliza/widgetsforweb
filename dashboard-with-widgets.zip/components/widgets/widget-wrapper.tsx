"use client"

import type React from "react"

import { useRef, useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { X, GripVertical } from "lucide-react"

interface WidgetWrapperProps {
  id: string
  position: { x: number; y: number }
  onPositionChange: (id: string, position: { x: number; y: number }) => void
  onRemove: (id: string) => void
  children: React.ReactNode
}

export function WidgetWrapper({ id, position, onPositionChange, onRemove, children }: WidgetWrapperProps) {
  const widgetRef = useRef<HTMLDivElement>(null)
  const [isDragging, setIsDragging] = useState(false)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging) return

      const deltaX = e.clientX - dragStart.x
      const deltaY = e.clientY - dragStart.y

      onPositionChange(id, {
        x: position.x + deltaX,
        y: position.y + deltaY,
      })

      setDragStart({ x: e.clientX, y: e.clientY })
    }

    const handleMouseUp = () => {
      setIsDragging(false)
    }

    if (isDragging) {
      document.addEventListener("mousemove", handleMouseMove)
      document.addEventListener("mouseup", handleMouseUp)
    }

    return () => {
      document.removeEventListener("mousemove", handleMouseMove)
      document.removeEventListener("mouseup", handleMouseUp)
    }
  }, [isDragging, dragStart, position, id, onPositionChange])

  const handleMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest(".drag-handle")) {
      setIsDragging(true)
      setDragStart({ x: e.clientX, y: e.clientY })
    }
  }

  return (
    <div
      ref={widgetRef}
      className="absolute cursor-move"
      style={{
        left: `${position.x}px`,
        top: `${position.y}px`,
      }}
      onMouseDown={handleMouseDown}
    >
      <div className="relative group">
        <div className="absolute -top-2 -right-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity">
          <Button onClick={() => onRemove(id)} size="icon" variant="destructive" className="h-8 w-8 rounded-full">
            <X className="h-4 w-4" />
          </Button>
        </div>
        <div className="absolute -top-2 -left-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity drag-handle cursor-grab active:cursor-grabbing">
          <Button size="icon" variant="secondary" className="h-8 w-8 rounded-full">
            <GripVertical className="h-4 w-4" />
          </Button>
        </div>
        {children}
      </div>
    </div>
  )
}
