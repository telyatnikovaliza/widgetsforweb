"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Trash2 } from "lucide-react"

interface Task {
  id: string
  text: string
  completed: boolean
}

export function TodoWidget() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [inputValue, setInputValue] = useState("")

  useEffect(() => {
    const saved = localStorage.getItem("todo-tasks")
    if (saved) {
      setTasks(JSON.parse(saved))
    }
  }, [])

  useEffect(() => {
    if (tasks.length > 0) {
      localStorage.setItem("todo-tasks", JSON.stringify(tasks))
    }
  }, [tasks])

  const addTask = () => {
    if (inputValue.trim()) {
      const newTask: Task = {
        id: Date.now().toString(),
        text: inputValue.trim(),
        completed: false,
      }
      setTasks([...tasks, newTask])
      setInputValue("")
    }
  }

  const toggleTask = (taskId: string) => {
    setTasks(tasks.map((task) => (task.id === taskId ? { ...task, completed: !task.completed } : task)))
  }

  const removeTask = (taskId: string) => {
    setTasks(tasks.filter((task) => task.id !== taskId))
  }

  return (
    <Card className="p-6 w-full shadow-lg">
      <h3 className="text-xl font-bold mb-4">To-Do List</h3>

      <div className="flex gap-2 mb-4">
        <Input
          placeholder="Add new task..."
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && addTask()}
        />
        <Button onClick={addTask} size="sm">
          Add
        </Button>
      </div>

      <div className="space-y-2 max-h-64 overflow-y-auto">
        {tasks.length === 0 ? (
          <p className="text-center text-gray-500 dark:text-gray-400 py-4">No tasks yet</p>
        ) : (
          tasks.map((task) => (
            <div
              key={task.id}
              className="flex items-center gap-2 p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
            >
              <Checkbox checked={task.completed} onCheckedChange={() => toggleTask(task.id)} />
              <span className={`flex-1 ${task.completed ? "line-through text-gray-500" : ""}`}>{task.text}</span>
              <Button onClick={() => removeTask(task.id)} size="icon" variant="ghost" className="h-8 w-8">
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))
        )}
      </div>

      <div className="mt-4 pt-4 border-t text-sm text-gray-600 dark:text-gray-400">
        Total: {tasks.length} | Completed: {tasks.filter((t) => t.completed).length}
      </div>
    </Card>
  )
}
