"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { TrendingUp, CheckCircle2, Target, Clock } from "lucide-react"

interface Task {
  id: string
  text: string
  completed: boolean
}

export function ProductivityWidget() {
  const [stats, setStats] = useState({
    tasksCompleted: 0,
    totalTasks: 0,
    productivity: 0,
    hoursWorked: 0,
  })

  useEffect(() => {
    const updateStats = () => {
      const tasksData = localStorage.getItem("todo-tasks")
      if (tasksData) {
        const tasks: Task[] = JSON.parse(tasksData)
        const completed = tasks.filter((t) => t.completed).length
        const total = tasks.length
        const productivity = total > 0 ? Math.round((completed / total) * 100) : 0

        setStats({
          tasksCompleted: completed,
          totalTasks: total,
          productivity,
          hoursWorked: completed * 0.5, // Estimate 0.5 hours per completed task
        })
      } else {
        setStats({
          tasksCompleted: 0,
          totalTasks: 0,
          productivity: 0,
          hoursWorked: 0,
        })
      }
    }

    // Update immediately
    updateStats()

    // Listen for changes in localStorage (from TodoWidget)
    const interval = setInterval(updateStats, 1000)

    return () => clearInterval(interval)
  }, [])

  return (
    <Card className="w-full shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-blue-500" />
          Productivity Stats
        </CardTitle>
        <CardDescription>Your daily performance overview</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-green-500" />
              Tasks Completed
            </span>
            <span className="font-semibold">
              {stats.tasksCompleted}/{stats.totalTasks}
            </span>
          </div>
          <Progress
            value={stats.totalTasks > 0 ? (stats.tasksCompleted / stats.totalTasks) * 100 : 0}
            className="h-2"
          />
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="flex items-center gap-2">
              <Target className="h-4 w-4 text-purple-500" />
              Productivity Score
            </span>
            <span className="font-semibold">{stats.productivity}%</span>
          </div>
          <Progress value={stats.productivity} className="h-2" />
        </div>

        <div className="pt-4 border-t">
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-2 text-sm">
              <Clock className="h-4 w-4 text-orange-500" />
              Hours Worked Today
            </span>
            <span className="text-2xl font-bold text-blue-600">{stats.hoursWorked.toFixed(1)}h</span>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2 pt-4 border-t">
          <div className="text-center p-2 bg-green-50 dark:bg-green-950 rounded">
            <div className="text-xs text-gray-600 dark:text-gray-400">Total</div>
            <div className="text-lg font-bold text-green-600">{stats.totalTasks}</div>
          </div>
          <div className="text-center p-2 bg-blue-50 dark:bg-blue-950 rounded">
            <div className="text-xs text-gray-600 dark:text-gray-400">Done</div>
            <div className="text-lg font-bold text-blue-600">{stats.tasksCompleted}</div>
          </div>
          <div className="text-center p-2 bg-purple-50 dark:bg-purple-950 rounded">
            <div className="text-xs text-gray-600 dark:text-gray-400">Left</div>
            <div className="text-lg font-bold text-purple-600">{stats.totalTasks - stats.tasksCompleted}</div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
